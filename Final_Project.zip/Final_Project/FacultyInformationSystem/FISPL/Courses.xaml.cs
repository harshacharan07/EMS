﻿using FISBLL;
using FISEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for Courses.xaml
    /// </summary>
    public partial class Courses : Page
    {
        public Courses()
        {
            InitializeComponent();
        }

        AdminBLL adminBLL = new AdminBLL();
        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Added = false;
                CoursesEntity coursesEntity = new CoursesEntity();
                //publicationsEntity.CourseID = int.Parse(txtfid.Text);
                coursesEntity.CourseName = txtCourseName.Text;
                coursesEntity.CourseCredits = int.Parse(txtCourseCredits.Text);
                coursesEntity.DeptID = int.Parse(txtDeptId.Text);


                Added = adminBLL.AddCoursesBLL(coursesEntity);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();

                }
                else
                    MessageBox.Show("Not Added");
            }
            catch (FISException.FISException fisException)
            {
                MessageBox.Show(fisException.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Fill the required fields");
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int courseId = int.Parse(txtCourseId.Text);
                bool deleteFaculty = adminBLL.DeleteCoursesBLL(courseId);
                if (deleteFaculty)
                {
                    MessageBox.Show("Deleted successfully");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (FISException.FISException fisException)
            {
                MessageBox.Show(fisException.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please provide course Id");
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool updated = false;
                int search = int.Parse(txtCourseId.Text);

                CoursesEntity courses = adminBLL.SearchCoursesBLL(search);
                if (courses != null)
                {
                    courses.CourseName = txtCourseName.Text;
                    courses.CourseCredits = int.Parse(txtCourseCredits.Text);
                    courses.DeptID = int.Parse(txtDeptId.Text);
                }
                updated = adminBLL.UpdateCoursesBLL(courses);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch (FISException.FISException fisException)
            {
                MessageBox.Show(fisException.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fill the required fields");
            }
        }

        public void LoadGrid()
        {
            DataTable table = new DataTable();
            table = adminBLL.GetAllCoursesBLL();
            datagrid.DataContext = table;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchCourseId = int.Parse(txtCourseId.Text);
                CoursesEntity course = new CoursesEntity();
                 course = adminBLL.SearchCoursesBLL(searchCourseId);
                if (course != null)
                {
                    txtCourseId.Text = course.CourseID.ToString();
                    txtCourseName.Text = course.CourseName;
                    txtCourseCredits.Text = course.CourseCredits.ToString();
                    txtDeptId.Text = course.DeptID.ToString();
                }
                else
                {
                    MessageBox.Show("Course not Found");
                }
            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter ID");
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
