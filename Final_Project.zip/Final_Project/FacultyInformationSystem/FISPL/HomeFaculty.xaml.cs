﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for HomeFaculty.xaml
    /// </summary>
    public partial class HomeFaculty : Page
    {
        public HomeFaculty()
        {
            InitializeComponent();
        }


        private void btn_PersonalInfo_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("PersonalInformations.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_WorkHistory_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("WorkHistory.xaml", UriKind.RelativeOrAbsolute));
            
        }

        private void btn_Publications_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("PublicationPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_GranInfo_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("GrantInformation.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_CoursesTaught_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("CourseTaught.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

            FISBLL.FISBLL fISBLL = new FISBLL.FISBLL();
            if (Application.Current.Resources["username"] != null)
            {
                tbWelcome.Text = "Welcome " + Application.Current.Resources["username"].ToString();
                int Id = fISBLL.GetfacultyIdBL(Application.Current.Resources["username"].ToString());
                Application.Current.Resources["facultyID"] = Id;
            }
            else
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}

   
