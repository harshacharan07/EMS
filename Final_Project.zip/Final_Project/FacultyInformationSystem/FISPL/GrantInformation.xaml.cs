﻿
using FISEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FISBLL;
using System.Data.SqlClient;
using System.Data;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for GrantInformation.xaml
    /// </summary>
    public partial class GrantInformation : Page
    {
        FISBLL.FISBLL facultyBLL = new FISBLL.FISBLL();
        public GrantInformation()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (AddGrantPL() == true)
            {
                MessageBox.Show("Grant Added Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Add Grant");

            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchGrantPL();

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (UpdateGrantPL() == true)
            {
                MessageBox.Show("Grant Updated Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Update Grant");

            }

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DeleteGrantPL() == true)
            {
                MessageBox.Show("Grant Deleted Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Delete Grant");

            }

        }
        private bool AddGrantPL()
        {
            bool isAdded = false;
            try
            {
            rtbGtDescription.SelectAll();
            GrantsEntity grants = new GrantsEntity();
            grants.GrantTitle = txtgtitle.Text;
            grants.FacultyID = int.Parse(txtfid.Text);

            grants.GrantDescription = rtbGtDescription.Selection.Text;

                isAdded = facultyBLL.AddGrantBL(grants);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("something went Wrong. Grant not Added");

            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Please enter required fields");
            }
            return isAdded;
        }
        private bool UpdateGrantPL()
        {
            bool isUpdated = false;
            try
            {
                rtbGtDescription.SelectAll();
            GrantsEntity grants = new GrantsEntity();
            grants.GrantTitle = txtgtitle.Text;
            grants.FacultyID = int.Parse(txtfid.Text);
            grants.GrantID = int.Parse(txtgid.Text);
            grants.GrantDescription = rtbGtDescription.Selection.Text;
                
                isUpdated = facultyBLL.UpdateGrantBL(grants);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("something went wrong. Grant not updated");

            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Please enter required fields");
            }
            return isUpdated;
        }
        private bool DeleteGrantPL()
        {
            bool isDeleted = false;
           
            try
            {
                int grantId = Convert.ToInt32(txtgid.Text);
                isDeleted = facultyBLL.DeleteGrantBL(grantId);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Something Went Wrong");

            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Please enter grant Id");
            }
            return isDeleted;
        }
        private void SearchGrantPL()
        {
           
            try
            {
                int grantId = Convert.ToInt32(txtgid.Text);
                GrantsEntity grants = facultyBLL.SearchGrantBL(grantId);
                
                if (grants != null)
                {
                    MessageBox.Show("Found");

                    txtgtitle.Text = grants.GrantTitle.ToString();
                    txtfid.Text = grants.FacultyID.ToString();
                    txtgid.Text = grants.GrantID.ToString();
                    rtbGtDescription.Selection.Text = grants.GrantDescription.ToString();

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
            
            catch (FISException.FISException Exception)
            {

                MessageBox.Show(Exception.Message);

            }
            catch (Exception Exception)
            {

                MessageBox.Show("Please enter grant Id");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }
        public void LoadGrid()
        {
            DataTable table = new DataTable();
            txtfid.Text = Application.Current.Resources["facultyID"].ToString();
            table = facultyBLL.GetAllGrantBL(int.Parse(txtfid.Text));
            datagrid.DataContext = table;
        }
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
