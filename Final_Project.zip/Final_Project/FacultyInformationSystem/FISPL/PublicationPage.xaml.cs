﻿using FISEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FISBLL;
using System.Data;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for PublicationPage.xaml
    /// </summary>
    public partial class PublicationPage : Page
    {
        public PublicationPage()
        {
            InitializeComponent();
        }
        PublicationsEntity publicationsEntity = new PublicationsEntity();
        FISBLL.FISBLL pubBLL = new FISBLL.FISBLL();
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            bool Added = false;
            try
            {
                // publicationsEntity.FacultyID = int.Parse(txtfid.Text);
                publicationsEntity.FacultyID = int.Parse(txtFacultyId.Text);
                publicationsEntity.PublicationTitle = txtPublicationTitle.Text;
                publicationsEntity.PublisherName = txtPublisherName.Text;
                publicationsEntity.ArticleName = txtArticleName.Text;
                publicationsEntity.PublicationLocation = txtPublicationLocation.Text;
                publicationsEntity.CitationDate = DateTime.Parse(txtCitationDate.Text);


                Added = pubBLL.AddPublicationBLL(publicationsEntity);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Not Added");
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception fe)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchfaculty = int.Parse(txtPublicationId.Text);
                PublicationsEntity publications = pubBLL.SearchPublicationsBL(searchfaculty);
                if (publications != null)
                {
                    txtFacultyId.Text = publications.FacultyID.ToString();
                    txtPublicationTitle.Text = publications.PublicationTitle;
                    txtArticleName.Text = publications.ArticleName;
                    txtPublisherName.Text = publications.PublisherName;
                    txtPublicationLocation.Text = publications.PublicationLocation;
                    txtCitationDate.Text = publications.CitationDate.ToString();
                }
                else
                {
                    MessageBox.Show("Publication not Found");
                }
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show("enter ID");
            }
            catch (Exception fe)
            {
                MessageBox.Show("Please enter ID");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool updated = false;
                int searchPublication = int.Parse(txtPublicationId.Text);
                PublicationsEntity publication = pubBLL.SearchPublicationsBL(searchPublication);
                if (publication != null)
                {
                    publication.FacultyID = int.Parse(txtFacultyId.Text);
                    publication.PublicationTitle = txtPublicationTitle.Text;
                    publication.PublisherName = txtPublisherName.Text;
                    publication.ArticleName = txtArticleName.Text;
                    publication.PublicationLocation = txtPublicationLocation.Text;
                    publication.CitationDate = DateTime.Parse(txtCitationDate.Text);
                }
                updated = pubBLL.UpdatePublicationsBL(publication);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception fe)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
               
            }

        }
        public void LoadGrid()
        {
            try
            {
                DataTable table = new DataTable();
                txtFacultyId.Text = Application.Current.Resources["facultyID"].ToString();
                table = pubBLL.GetAllPublicationsBL(int.Parse(Application.Current.Resources["facultyID"].ToString()));
                datagrid.DataContext = table;
            }
            catch(Exception ex) { }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int pubId = int.Parse(txtPublicationId.Text);
                bool deletePublication = pubBLL.DeletePublicationsBL(pubId);
                if (deletePublication)
                {
                    MessageBox.Show("Deleted successfully");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception fe)
            {
                MessageBox.Show("Please enter publication Id");
            }
        }
    }
}
