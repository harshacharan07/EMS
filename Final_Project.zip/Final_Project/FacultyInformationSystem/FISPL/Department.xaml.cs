﻿using FISBLL;
using FISEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for Department.xaml
    /// </summary>
    public partial class Department : Page
    {
        public Department()
        {
            InitializeComponent();
        }

        AdminBLL adminBLL = new AdminBLL();
        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Added = false;
                DepartmentEntity department = new DepartmentEntity();

                department.DeptName = txtDeptName.Text;

                Added = adminBLL.AddDepartmentsBLL(department);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();

                }
                else
                    MessageBox.Show("Not Added");
            }
            catch(FISException.FISException ex) {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        public void LoadGrid()
        {
            DataTable table = adminBLL.ViewAllDepartmentBLL();
            datagrid.DataContext = table;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }

        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
