﻿using FISBLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for SearchPublication.xaml
    /// </summary>
    public partial class SearchPublication : Page
    {
        public SearchPublication()
        {
            InitializeComponent();
           
        }
        StudentBLL studentBLL = new StudentBLL();
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] != null)
            {
                tbWelcome.Text = "Welcome " + Application.Current.Resources["username"].ToString();
                BindComboBox(comboBoxName);
            }
            else
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            
        }

        public void BindComboBox(ComboBox comboBoxName)
        {
            DataSet ds = studentBLL.GetFacultyNameBLL();
            comboBoxName.ItemsSource = ds.Tables[0].DefaultView;
            comboBoxName.DisplayMemberPath = ds.Tables[0].Columns["UserName"].ToString();
            comboBoxName.SelectedValuePath = ds.Tables[0].Columns["FacultyId"].ToString();
        }

        private void comboBoxName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxZone1.DisplayMemberPath = null;
            ComboBoxZone1.SelectedValuePath = null;
            string selectedvalue=comboBoxName.SelectedValue.ToString();
            DataSet ds = studentBLL.GetPublicationTitleBLL(selectedvalue);
            ComboBoxZone1.ItemsSource = ds.Tables[0].DefaultView;
            ComboBoxZone1.DisplayMemberPath = ds.Tables[0].Columns["PublicationTitle"].ToString();
            ComboBoxZone1.SelectedValuePath = ds.Tables[0].Columns["PublicationID"].ToString();
        }

        private void ComboBoxZone1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedvalue =ComboBoxZone1.SelectedValue.ToString();
            DataTable dataTable = studentBLL.ShowPublicationBLL(selectedvalue);
            dgViewPublication.DataContext = dataTable;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }

}
