﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FISEntity;
using FISBLL;
using System.Data;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for WorkHistory.xaml
    /// </summary>
    public partial class WorkHistory : Page
    {
        public WorkHistory()
        {
            InitializeComponent();
        }
        FISBLL.FISBLL workBLL = new FISBLL.FISBLL();

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            FISEntity.WorkHistory workHistory = new FISEntity.WorkHistory();
            bool Added = false;
            try
            {
                workHistory.FacultyID = int.Parse(txtFacultyId.Text);
                workHistory.Organization = txtOrganization.Text;
                workHistory.JobTitle = txtJobTitle.Text;
                workHistory.JobBeginDate = Convert.ToDateTime(txtJobBegin.Text);
                workHistory.JobEndDate = Convert.ToDateTime(txtJobEnd.Text);
                workHistory.JobResponsibilities = txtJobResponsibilities.Text;
                workHistory.JobType = txtJobtype.Text;

                Added = workBLL.AddWorkBLL(workHistory);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Not Added");
            }
            catch(FISException.FISException fisException)
            {
                MessageBox.Show(fisException.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchfaculty = int.Parse(txtWorkid.Text);
                FISEntity.WorkHistory workhistory = workBLL.SearchWorkHistoryBL(searchfaculty);
                if (workhistory != null)
                {
                    txtFacultyId.Text = workhistory.FacultyID.ToString();
                    txtOrganization.Text = workhistory.Organization;
                    txtJobTitle.Text = workhistory.JobTitle;
                    txtJobBegin.Text = workhistory.JobBeginDate.ToString();
                    txtJobEnd.Text = workhistory.JobEndDate.ToString();
                    txtJobResponsibilities.Text = workhistory.JobResponsibilities;
                    txtJobtype.Text = workhistory.JobType;

                }
                else
                {
                    MessageBox.Show("WorkHistory not Found");
                }
            }
            catch(FISException.FISException)
            {
                MessageBox.Show("Please enter ID");
            }
            catch(Exception)
            {
                MessageBox.Show("Please enter ID");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool updated = false;
                int updateFaculty = int.Parse(txtWorkid.Text);
                FISEntity.WorkHistory workhistory = workBLL.SearchWorkHistoryBL(updateFaculty);
                if (workhistory != null)
                {

                    workhistory.FacultyID = int.Parse(txtFacultyId.Text);
                    workhistory.Organization = txtOrganization.Text;
                    workhistory.JobTitle = txtJobTitle.Text;
                    workhistory.JobBeginDate = Convert.ToDateTime(txtJobBegin.Text);
                    workhistory.JobEndDate = Convert.ToDateTime(txtJobEnd.Text);
                    workhistory.JobResponsibilities = txtJobResponsibilities.Text;
                    workhistory.JobType = txtJobtype.Text;

                }
                updated = workBLL.UpdateWorkHistoryBL(workhistory);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception fe)
            {
                MessageBox.Show("Please enter workhistory id");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int facId = int.Parse(txtWorkid.Text);
                bool deleteWork = workBLL.DeleteWorkHistoryBL(facId);
                if (deleteWork)
                {
                    MessageBox.Show("Deleted successfully");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show("Some thing went Wrong");
            }
            catch (Exception fe)
            {
                MessageBox.Show("please enter ID");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }
        public void LoadGrid()
        {
            DataTable table = new DataTable();
            txtFacultyId.Text = Application.Current.Resources["facultyID"].ToString();
            table = workBLL.GetAllWorkHistoryBL(int.Parse(txtFacultyId.Text));
            datagrid.DataContext = table;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }

       
    }
}
