﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for CourseTaught.xaml
    /// </summary>
    public partial class CourseTaught : Page
    {
        public CourseTaught()
        {
            InitializeComponent();
        }
        FISBLL.FISBLL fISBLL = new FISBLL.FISBLL();
        FISEntity.CoursesTaughtEntity coursesTaught = new FISEntity.CoursesTaughtEntity();

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {



            if (AddCourseTaughtPL() == true)
            {
                MessageBox.Show("Courses Taught Added Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Add Courses Taught");

            }
        }
        private bool AddCourseTaughtPL()
        {
            bool isAdded = false;
            try
            {
                coursesTaught.CourseID = int.Parse(txtCourseId.Text);
            coursesTaught.FacultyID = int.Parse(txtFacultyId.Text);
            coursesTaught.SubjectID = int.Parse(txtSubjectId.Text);
            coursesTaught.FirstDateTaught = DateTime.Parse(dpFirstTaught.Text);

            
                isAdded = fISBLL.AddCourseTaughtBL(coursesTaught);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Something Went wrong");

            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Please fill the required fields");
            }
            return isAdded;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCourseTaughtPL();

        }
        private void SearchCourseTaughtPL()
        {
            try
            {
                int searchCourseTaughtID = int.Parse(txtCourseTaughtID.Text);
                coursesTaught = fISBLL.SearchCourseTaughtBL(searchCourseTaughtID);
                
                if (coursesTaught != null)
                {
                    MessageBox.Show("Found");
                    txtCourseTaughtID.Text = coursesTaught.CourseTaughtID.ToString();
                    txtCourseId.Text = coursesTaught.CourseID.ToString();
                    txtFacultyId.Text = coursesTaught.FacultyID.ToString();
                    txtSubjectId.Text = coursesTaught.SubjectID.ToString();
                    dpFirstTaught.Text = coursesTaught.FirstDateTaught.ToString();
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }

            catch (FISException.FISException Exception)
            {

                MessageBox.Show(Exception.Message);

            }
            catch (Exception Exception)
            {

                MessageBox.Show("Please enter Id");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (UpdateCourseTaughtPL() == true)
            {
                MessageBox.Show("Courses Taught Updated Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Update Courses Taught");

            }

        }
        private bool UpdateCourseTaughtPL()
        {
            bool isUpdated = false;
            try
            {
                int searchCourseTaughtID = int.Parse(txtCourseTaughtID.Text);
            coursesTaught = fISBLL.SearchCourseTaughtBL(searchCourseTaughtID);
            if (coursesTaught != null)
            {
                coursesTaught.CourseTaughtID = int.Parse(txtCourseTaughtID.Text);
                coursesTaught.CourseID = int.Parse(txtCourseId.Text);
                coursesTaught.FacultyID = int.Parse(txtFacultyId.Text);
                coursesTaught.SubjectID = int.Parse(txtSubjectId.Text);
                coursesTaught.FirstDateTaught = DateTime.Parse(dpFirstTaught.Text);
            }
            else
            {
                MessageBox.Show("CourseTaughtID doesn't exists");
            }
            
                isUpdated = fISBLL.UpdateCourseTaughtBL(coursesTaught);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("some thing went wrong");

            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());
            }

            catch (Exception Exception)
            {
                MessageBox.Show("Please enter required fields");
            }
            return isUpdated;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DeleteCourseTaughtPL() == true)
            {
                MessageBox.Show("Courses Taught Deleted Successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Failed to Delete Courses Taught");

            }
        }
        private bool DeleteCourseTaughtPL()
        {
            bool isDeleted = false;
            
            try
                {
                int deleteCourseTaughtID = int.Parse(txtCourseTaughtID.Text);
                isDeleted = fISBLL.DeleteCourseTaughtBL(deleteCourseTaughtID);
                }
                catch (SqlException Exception)
                {
                    MessageBox.Show("enter ID");

                }
                catch (FISException.FISException Exception)
                {
                    MessageBox.Show(Exception.Message.ToString());
                }
                catch (Exception Exception)
                {
                    MessageBox.Show("Please Enter course taught Id");
                }

           
            return isDeleted;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }

        public void LoadGrid()
        {
            DataTable table = new DataTable();
            txtFacultyId.Text = Application.Current.Resources["facultyID"].ToString();
            table = fISBLL.GetAllCourseTaughtBL(int.Parse(txtFacultyId.Text));
            datagrid.DataContext = table;
        }

    }
}