﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISException
{
    public class FISException:ApplicationException
    {
        public FISException() : base() { }

        public FISException(string message) : base(message) { }

        public FISException(string message, Exception innerException) : base(message, innerException) { }
    }
}
