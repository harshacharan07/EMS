﻿using FISEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FISBLL
{
   public  class UserBLL
    {
        static FISDAL.UserDAL userDAL = new FISDAL.UserDAL();

        private bool ValidateUser(FISEntity.UserEntity User)
        {
            StringBuilder sb = new StringBuilder();
            bool validateUser = true;
            if (User.UserName == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "User Name Required");
            }
            if (User.Password.Length < 8)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password should not be less than 8 characters");
            }
            if (User.Password==string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password Required");
            }
            if (User.UserType == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "UserType is Required");
            }
            if (validateUser == false)
                throw new FISException.FISException(sb.ToString());
            return validateUser;

        }


        public bool GetPassword(UserEntity user)
        {
            bool isuserValid = false;
            try
            {
                if (ValidateUser(user))
                {
                    isuserValid = userDAL.GetUserPassword(user);
                }
                else
                {
                    throw new FISException.FISException();
                }

            }
            catch (FISException.FISException exception)
            {
                throw exception;

            }
            return isuserValid;
        }
    }
}
