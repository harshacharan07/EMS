﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FISDAL;
using FISEntity;
using FISException;

namespace FISBLL
{
    public class FISBLL
    {
        static FISDAL.FacultyDAL facultyDAL = new FISDAL.FacultyDAL();

        public int GetfacultyIdBL(string userName)
        {
            FacultyEntity facultyEntity = new FacultyEntity();
            int Id = 0;
            try
            {
                //FISDAL.WorkHistoryDAL workHistory = new FISDAL.WorkHistoryDAL();
                Id = facultyDAL.GetFacultyIdDAL(userName);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Id;
        }
        
        //Validations for Faculty
        private static bool ValidateFaculty(FISEntity.FacultyEntity Faculty)
        {
            StringBuilder sb = new StringBuilder();
            bool validateFaculty = true;

            //if (Faculty.FacultyID <= 0)
            //{
            //    validateFaculty = false;
            //    sb.Append(Environment.NewLine + "Faculty ID Required");

            //}
            if (Faculty.FirstName == string.Empty)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "First Name Required");
            }
            if (Faculty.LastName == string.Empty)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Last Name Required");
            }
            if (Faculty.Address == string.Empty)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Address Required");
            }
            if (Faculty.City == string.Empty)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "City can not be left blank");
            }
            if (Faculty.State == string.Empty)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Faculty state Required");

            }
            if (Faculty.Pincode.ToString().Length!=6)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Pin code must be 6 digits");
            }
            if (Faculty.MobileNo.ToString().Length!=10)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Mobile no should be 10 digits.");
            }
           

            if (Convert.ToDateTime(Faculty.HireDate.ToString().Substring(0, 10)) > Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10)))
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Invalid Hire Date");
            }
           
            if (!Regex.Match(Faculty.EmailAddress, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$").Success)
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "invalid Email Address");
            }
            if (Convert.ToDateTime(Faculty.DateOfBirth.ToString().Substring(0, 10)) >= Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10))|| Convert.ToDateTime(Faculty.DateOfBirth.ToString().Substring(0, 10)) > Convert.ToDateTime(Faculty.HireDate.ToString().Substring(0, 10)))
            {
                validateFaculty = false;
                sb.Append(Environment.NewLine + "Invalid Date of Birth ");
            }

            if (validateFaculty == false)
                throw new FISException.FISException(sb.ToString());
            return validateFaculty;

        }

        //Validations for Publications
        private bool ValidatePublications(FISEntity.PublicationsEntity Publications)
        {
            StringBuilder sb = new StringBuilder();
            bool validatePublications = true;

            
            if (Publications.PublicationTitle == string.Empty)
            {
                validatePublications = false;
                sb.Append(Environment.NewLine + "Publication Title Required");
            }
            if (Publications.ArticleName == string.Empty)
            {
                validatePublications = false;
                sb.Append(Environment.NewLine + "Article Name Required");
            }
            if (Publications.PublisherName == string.Empty)
            {
                validatePublications = false;
                sb.Append(Environment.NewLine + "Publisher Name Required");
            }
            if (Publications.PublicationLocation == string.Empty)
            {
                validatePublications = false;
                sb.Append(Environment.NewLine + "Publication Location Required");
            }
            if (Convert.ToDateTime(Publications.CitationDate.ToString().Substring(0, 10)) != Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10)))
            {
                validatePublications = false;
                sb.Append(Environment.NewLine + "Invalid Date");
            }

            if (validatePublications == false)
                throw new FISException.FISException(sb.ToString());
            return validatePublications;
           
        }

        //Validations for Work History
        private bool ValidateWorkHistory(FISEntity.WorkHistory WorkHistory)
        {
            StringBuilder sb = new StringBuilder();
            bool validateWorkHistory = true;
            
            if (WorkHistory.Organization == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Organization Required");
            }
            if (WorkHistory.JobTitle == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobTitle Required");
            }
            if (Convert.ToDateTime(WorkHistory.JobBeginDate.ToString().Substring(0, 10)) > Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10)))
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Invalid job begin Date");
            }
            if (Convert.ToDateTime(WorkHistory.JobEndDate.ToString().Substring(0, 10)) <= Convert.ToDateTime(WorkHistory.JobBeginDate.ToString().Substring(0, 10)))
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Invalid job end Date");
            }
            if (WorkHistory.JobResponsibilities == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobResponsibilities Required");
            }
            if (WorkHistory.JobType == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobType Required");
            }
            if (validateWorkHistory == false)
                throw new FISException.FISException(sb.ToString());
            return validateWorkHistory;
        }

        //Validations for Degrees
        //private bool ValidateDegrees(FISEntity.DegreesEntity Degrees)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    bool validateDegrees = true;

        //    if (Degrees.DegreeID <= 0)
        //    {
        //        validateDegrees = false;
        //        sb.Append(Environment.NewLine + "Degree ID Required");

        //    }
        //    if (Degrees.Degree == string.Empty)
        //    {
        //        validateDegrees = false;
        //        sb.Append(Environment.NewLine + "Degree Required");
        //    }
        //    if (Degrees.Specialization == string.Empty)
        //    {
        //        validateDegrees = false;
        //        sb.Append(Environment.NewLine + "Specialization Required");
        //    }
        //    if (Degrees.DegreeYear < 4 || Degrees.DegreeYear > 4)
        //    {
        //        validateDegrees = false;
        //        sb.Append(Environment.NewLine + "Invalid Year");
        //    }

        //    if (Degrees.Grade != 'A' || Degrees.Grade != 'B' || Degrees.Grade != 'C' || Degrees.Grade != 'D')
        //    {
        //        validateDegrees = false;
        //        sb.Append(Environment.NewLine + "Enter Valid Grade");
        //    }

        //    if (validateDegrees == false)
        //        throw new FISException.FISException(sb.ToString());
        //    return validateDegrees;
        //}

        //Validations for Work Grants
        private bool ValidateGrants(FISEntity.GrantsEntity Grants)
        {
            StringBuilder sb = new StringBuilder();
            bool validateGrants = true;
            if (Grants.GrantTitle == string.Empty)
            {
                validateGrants = false;
                sb.Append(Environment.NewLine + "Grant Title Required");
            }
            if (Grants.GrantDescription.Length <= 0)
            {
                validateGrants = false;
                sb.Append(Environment.NewLine + "GrantDescription is Required");
            }
            if (validateGrants == false)
                throw new FISException.FISException(sb.ToString());
            return validateGrants;

        }

        //Validations for Work Courses
        private bool ValidateCourses(FISEntity.CoursesEntity Courses)
        {
            StringBuilder sb = new StringBuilder();
            bool validateCourses = true;
            if (Courses.CourseName == string.Empty)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Course Name Required");
            }
            if (Courses.CourseCredits <= 0)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Course Credits is Required");
            }
            if (Courses.DeptID.ToString() == string.Empty)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Dept ID is Required");
            }
            if (validateCourses == false)
                throw new FISException.FISException(sb.ToString());
            return validateCourses;

        }

        //Validations for  Department
        private bool ValidateDept(FISEntity.DepartmentEntity Dept)
        {
            StringBuilder sb = new StringBuilder();
            bool validateDept = true;
            
            if (Dept.DeptName == string.Empty)
            {
                validateDept = false;
                sb.Append(Environment.NewLine + "DeptName Required");
            }

            if (validateDept == false)
                throw new FISException.FISException(sb.ToString());
            return validateDept;

        }

        //Validations for  Designation
        //private bool ValidateDesignation(FISEntity.DesignationEntity Designation)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    bool validateDesignation = true;

        //    if (Designation.DesignationID <= 0)
        //    {
        //        validateDesignation = false;
        //        sb.Append(Environment.NewLine + "DesignationID Required");

        //    }
        //    if (Designation.DesignationName == string.Empty)
        //    {
        //        validateDesignation = false;
        //        sb.Append(Environment.NewLine + "DesignationName Required");
        //    }

        //    if (validateDesignation == false)
        //        throw new FISException.FISException(sb.ToString());
        //    return validateDesignation;
        //}

        //Validations for  Subject
        private bool ValidateSubject(FISEntity.SubjectEntity Subject)
        {
            StringBuilder sb = new StringBuilder();
            bool validateSubject = true;
            if (Subject.SubjectName == string.Empty)
            {
                validateSubject = false;
                sb.Append(Environment.NewLine + "Subject Name Required");
            }

            if (validateSubject == false)
                throw new FISException.FISException(sb.ToString());
            return validateSubject;
        }

        //Validations for  CoursesTaught
        private bool ValidateCourseTaught(CoursesTaughtEntity CourseTaught)
        {
            StringBuilder sb = new StringBuilder();
            bool validateCourseTaught = true;
            if (CourseTaught.CourseID<=0)
            {
                validateCourseTaught = false;
                sb.Append(Environment.NewLine + "CourseID is Required");
            }
            if (CourseTaught.SubjectID<=0)
            {
                validateCourseTaught = false;
                sb.Append(Environment.NewLine + "subjectID is Required");
            }
            if (Convert.ToDateTime(CourseTaught.FirstDateTaught.ToString().Substring(0, 10)) > Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10)))
            {
                validateCourseTaught = false;
                sb.Append(Environment.NewLine + "Invalid Date");
            }
            if (validateCourseTaught == false)
                throw new FISException.FISException(sb.ToString());
            return validateCourseTaught;
        }

        //Add,update,delete,search for Faculty
        public  bool AddFacultyBLL(FISEntity.FacultyEntity newFaculty)
        {
            bool facultyAdded = false;
            try
            {
                if (ValidateFaculty(newFaculty))
                {
                    facultyAdded = facultyDAL.AddFacultyDAL(newFaculty);
                }
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return facultyAdded;
        }

        public DataTable GetAllFacultyBL(string userName)
        {
            DataTable table = new DataTable();
            try
            {
                //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                table = facultyDAL.GetAllFacultyDAL(userName);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }

        public bool DeleteFacultyBLL(int deleteFacultyID)
        {
            bool FacultyDeleted = false;
            try
            {
                if (deleteFacultyID > 0)
                {
                    //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                    FacultyDeleted = facultyDAL.DeleteFacultyDAL(deleteFacultyID);
                }
                else
                {
                    throw new FISException.FISException("Invalid faculty ID");
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return FacultyDeleted;
        }

        public  FISEntity.FacultyEntity SearchFacultyBLL(int searchFacultyID ,string userName)
        {
            FISEntity.FacultyEntity searchFaculty = null;
            try
            {
                //FISDAL.FacultyDAL Faculty = new FISDAL.FacultyDAL();
                searchFaculty = facultyDAL.SearchFacultyDAL(searchFacultyID,userName);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchFaculty;

        }

        public bool UpdateFacultyBLL(FISEntity.FacultyEntity updateFaculty)
        {
            bool FacultyUpdated = false;
            try
            {
                if (ValidateFaculty(updateFaculty))
                {
                    FacultyUpdated = facultyDAL.UpdateFacultyDAL(updateFaculty);
                }
            }
            catch (FISException.FISException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return FacultyUpdated;
        }

        //Add, update,search,delete for publications
        public bool AddPublicationBLL(FISEntity.PublicationsEntity newPublications)
        {
            bool publicationsAdded = false;
            try
            {
                if (ValidatePublications(newPublications))
                {
                    publicationsAdded = facultyDAL.AddPublicationDAL(newPublications);
                }
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return publicationsAdded;
        }

        public DataTable GetAllPublicationsBL(int facultyId)
        {
            DataTable table = null;
            try
            {
                //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                table = facultyDAL.GetAllPublicationsDAL(facultyId);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }

        public bool DeletePublicationsBL(int deletePublicationID)
        {
            bool PublicationDeleted = false;
            try
            {
                if (deletePublicationID > 0)
                {
                    //FISDAL.PublicationsDAL publications = new FISDAL.PublicationsDAL();
                    PublicationDeleted = facultyDAL.DeletePublications(deletePublicationID);
                }
                else
                {
                    throw new FISException.FISException("Invalid Exception ID");
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PublicationDeleted;
        }

        public  FISEntity.PublicationsEntity SearchPublicationsBL(int searchPublicationID)
        {
            FISEntity.PublicationsEntity searchPublications = null;
            try
            {
                //FISDAL.PublicationsDAL Publications = new FISDAL.PublicationsDAL();
                searchPublications = facultyDAL.SearchPublicationsDAL(searchPublicationID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPublications;

        }

        public bool UpdatePublicationsBL(FISEntity.PublicationsEntity updatePublications)
        {
            bool PublicationsUpdated = false;
            try
            {
                if (ValidatePublications(updatePublications))
                {
                    PublicationsUpdated = facultyDAL.UpdatePublicationDAL(updatePublications);
                }
            }
            catch (FISException.FISException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PublicationsUpdated;
        }

        ////Add,update,search,delete for Workhistory

        public bool AddWorkBLL(FISEntity.WorkHistory newWorkHistory)
        {
            bool WorkHistoryAdded = false;
            try
            {
               if (ValidateWorkHistory(newWorkHistory))
                {
                  
                    WorkHistoryAdded = facultyDAL.AddWorkHistoryDAL(newWorkHistory);
                }
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return WorkHistoryAdded;
        }

        public DataTable GetAllWorkHistoryBL(int facultyID)
        {
            DataTable table = null;
            try
            {
                //FISDAL.WorkHistoryDAL workHistory = new FISDAL.WorkHistoryDAL();
                table = facultyDAL.GetAllWorkDAL(facultyID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }

        public bool DeleteWorkHistoryBL(int deleteWorkHistoryID)
        {
            bool workHistoryDeleted = false;
            try
            {
               if (deleteWorkHistoryID > 0)
                {
                  
                    workHistoryDeleted = facultyDAL.DeleteWorkHistory(deleteWorkHistoryID);
                }
                else
                {
                    throw new FISException.FISException("Invalid ID");
                }
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return workHistoryDeleted;
        }

        public FISEntity.WorkHistory SearchWorkHistoryBL(int searchWorkHistoryID)
        {
            FISEntity.WorkHistory searchWorkHistory = null;
            try
            {
               
                searchWorkHistory = facultyDAL.SearchWorkHistoryDAL(searchWorkHistoryID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchWorkHistory;

        }

        public bool UpdateWorkHistoryBL(FISEntity.WorkHistory updateWorkHistory)
        {
            bool WorkHistoryUpdated = false;
            try
            {
                if (ValidateWorkHistory(updateWorkHistory))
                {

                    WorkHistoryUpdated = facultyDAL.UpdateWorkHistory(updateWorkHistory);
                }
            }
            catch (FISException.FISException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return WorkHistoryUpdated;
        }

        ////Add,update,search ,delete for Degrees

        //public bool Add(FISEntity.DegreesEntity newDegrees)
        //{
        //    bool DegreeesAdded = false;
        //    try
        //    {
        //        if (ValidateDegrees(newDegrees))
        //        {
        //            FISDAL.DegreesDAL degrees = new FISDAL.DegreesDAL();
        //            DegreeesAdded = DegreesDAL.AddDegreesDAL(newDegrees);
        //        }
        //    }
        //    catch (FISException.FISException ex)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return DegreeesAdded;
        //}

        //public static List<FISEntity.DegreesEntity> GetAllDegreesBL()
        //{
        //    List<FISEntity.DegreesEntity> DegreesList = null;
        //    try
        //    {
        //        FISDAL.DegreesDAL degrees = new FISDAL.DegreesDAL();
        //        DegreesList = DegreesDAL.GetAllDegreesDAL();
        //    }
        //    catch (FISException.FISException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return DegreesList;
        //}

        //public static bool DeleteDegreesBL(int deleteDegreeID)
        //{
        //    bool DegreesDeleted = false;
        //    try
        //    {
        //        if (deleteDegreeID > 0)
        //        {
        //            FISDAL.DegreeDAL degrees = new FISDAL.DegreeDAL();
        //            DegreesDeleted = DegreeDAL.DeleteDegreesDAL(deleteDegreeID);
        //        }
        //        else
        //        {
        //            throw new FISException.FISException("Invalid Exception ID");
        //        }
        //    }
        //    catch (FISException.FISException ex)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return DegreesDeleted;
        //}

        //public static FISEntity.DegreesEntity SearchDegreeBL(int searchDegreeID)
        //{
        //    FISEntity.DegreesEntity searchDegree = null;
        //    try
        //    {
        //        FISDAL.DegreeDAL degrees = new FISDAL.DegreeDAL();
        //        searchDegree = DegreeDAL.SearchDegreeDAL(searchDegreeID);
        //    }
        //    catch (FISException.FISException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchDegree;

        //}

        //public  bool UpdateDegreesBL(FISEntity.DegreesEntity updateDegrees)
        //{
        //    bool DegreesUpdated = false;
        //    try
        //    {
        //        if (ValidateDegrees(updateDegrees))
        //        {
        //            FISDAL.DegreesDAL degrees = new FISDAL.DegreesDAL();
        //            DegreesUpdated = DegreesDAL.UpdateDegreesDAL(updateDegrees);
        //        }
        //    }
        //    catch (FISException.FISException)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return DegreesUpdated;
        //}

        ////Add update search delete for CoursesTaughtEntity
        public DataTable GetAllCourseTaughtBL(int facultyID)
        {
            DataTable table = null;
            try
            {
                table = facultyDAL.GetAllCourseTaughtDAL(facultyID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }


        public bool UpdateCourseTaughtBL(CoursesTaughtEntity coursesTaughtEntity)
        {
            bool CourseTaughtUpdated = false;
            try
            {
                if (ValidateCourseTaught(coursesTaughtEntity))
                {
                    CourseTaughtUpdated = facultyDAL.UpdateCoursesTaughtDAL(coursesTaughtEntity);
                }
            }
            catch (FISException.FISException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CourseTaughtUpdated;
        }

        public bool DeleteCourseTaughtBL(int deleteCourseTaughtID)
        {
            bool CourseTaughtDeleted = false;
            try
            {
                if (deleteCourseTaughtID > 0)
                {
                   
                    CourseTaughtDeleted = facultyDAL.DeleteCoursesTaughtDAL(deleteCourseTaughtID);
                }
                else
                {
                    throw new FISException.FISException("Invalid Exception ID");
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CourseTaughtDeleted;
        }
        public bool AddCourseTaughtBL(CoursesTaughtEntity coursesTaughtEntity)
        {
            bool courseTaughtAdded = false;
            try
            {
                if (ValidateCourseTaught(coursesTaughtEntity))
                {
                    courseTaughtAdded = facultyDAL.AddCoursesTaughtDAL(coursesTaughtEntity);
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return courseTaughtAdded;
        }
        public CoursesTaughtEntity SearchCourseTaughtBL(int searchCourseTaughtID)
        {
            CoursesTaughtEntity searchCourseTaught = null;
            try
            {
                searchCourseTaught = facultyDAL.SearchCoursesTaughtDAL(searchCourseTaughtID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCourseTaught;

        }
        public bool UpdateGrantBL(GrantsEntity grant)
        {
            bool GrantUpdated = false;
            try
            {
                if (ValidateGrants(grant))
                {
                   
                    GrantUpdated = facultyDAL.UpdateGrant(grant);
                }
            }
            catch (FISException.FISException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return GrantUpdated;
        }

        public bool DeleteGrantBL(int deleteGrantID)
        {
            bool GrantsDeleted = false;
            try
            {
                if (deleteGrantID > 0)
                {
                   
                    GrantsDeleted = facultyDAL.DeleteGrant(deleteGrantID);
                }
                else
                {
                    throw new FISException.FISException("Invalid ID");
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return GrantsDeleted;
        }
        public bool AddGrantBL(GrantsEntity grant)
        {
            bool GrantAdded = false;
            try
            {
                if (ValidateGrants(grant))
                {
                    GrantAdded = facultyDAL.AddGrant(grant);
                }
            }
            catch (FISException.FISException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return GrantAdded;
        }
        public GrantsEntity SearchGrantBL(int GrantID)
        {
            GrantsEntity searchGrant = null;
            try
            {
              
                searchGrant = facultyDAL.SearchGrant(GrantID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGrant;

        }

        public DataTable GetAllGrantBL(int facultyId)
        {
            DataTable table = null;
            try
            {
                //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                table = facultyDAL.GetAllGrantsDAL(facultyId);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }
    }


}

