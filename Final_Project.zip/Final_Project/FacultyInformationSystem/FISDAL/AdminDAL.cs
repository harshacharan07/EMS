﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FISEntity;
using FISException;

namespace FISDAL
{
    public class AdminDAL
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        SqlCommand command = new SqlCommand();

        public bool AddUserDAL(UserEntity user)
        {
            bool isAdded = false;
            try
            {

                command.CommandText = "FIS_14_NOV.usp_InsertUsers";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@UserName", user.UserName);
                command.Parameters.AddWithValue("@Password", user.Password);
                command.Parameters.AddWithValue("@UserType", user.UserType);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public List<FacultyEntity> ViewAllFaculty()
        {

            List<FacultyEntity> ObjFacultyList = new List<FacultyEntity>();
            try
            {

                SqlDataReader ObjSqlDataReader;
                command.CommandText = "FIS_14_NOV.usp_SelectFaculty";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    FacultyEntity ObjTempFaculty;

                    while (ObjSqlDataReader.Read())
                    {
                        ObjTempFaculty = new FacultyEntity();
                        ObjTempFaculty.FacultyID = ObjSqlDataReader.GetInt32(0);
                        ObjTempFaculty.FirstName = ObjSqlDataReader.GetString(2);
                        ObjTempFaculty.LastName = ObjSqlDataReader.GetString(3);
                        ObjTempFaculty.Address = ObjSqlDataReader.GetString(4);
                        ObjTempFaculty.City = ObjSqlDataReader.GetString(5);
                        ObjTempFaculty.State = ObjSqlDataReader.GetString(6);
                        ObjTempFaculty.Pincode = ObjSqlDataReader.GetInt32(7);
                        ObjTempFaculty.MobileNo = ObjSqlDataReader.GetInt32(8);
                        ObjTempFaculty.HireDate = ObjSqlDataReader.GetDateTime(9);
                        ObjTempFaculty.EmailAddress = ObjSqlDataReader.GetString(10);
                        ObjTempFaculty.DateOfBirth = ObjSqlDataReader.GetDateTime(11);
                        ObjTempFaculty.DeptID = ObjSqlDataReader.GetInt32(12);
                        ObjTempFaculty.DesignationID = ObjSqlDataReader.GetInt32(13);
                        ObjTempFaculty.workHistories.WorkHistoryID = ObjSqlDataReader.GetInt32(14);
                        ObjTempFaculty.workHistories.Organization = ObjSqlDataReader.GetString(16);
                        ObjTempFaculty.workHistories.JobTitle = ObjSqlDataReader.GetString(17);
                        ObjTempFaculty.workHistories.JobBeginDate = ObjSqlDataReader.GetDateTime(18);
                        ObjTempFaculty.workHistories.JobEndDate = ObjSqlDataReader.GetDateTime(19);
                        ObjTempFaculty.workHistories.JobResponsibilities = ObjSqlDataReader.GetString(20);
                        ObjTempFaculty.workHistories.JobType = ObjSqlDataReader.GetString(21);
                        ObjFacultyList.Add(ObjTempFaculty);
                    }
                }
                ObjSqlDataReader.Close();

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return ObjFacultyList;
        }

        public bool AddDepartments(DepartmentEntity department)
        {
            bool isAdded = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_InsertDepartments";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@DeptName", department.DeptName);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();
                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException("Something Went Wrong");
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public DataTable GetAllDepartmentDAL()
        {
            DataTable table = new DataTable();
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_SelectDepartment";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);

                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }
        //public bool UpdateDepartments(DepartmentEntity department)
        //{
        //    bool isUpdate = false;

        //    try
        //    {
        //        command.CommandText = "FIS_14_NOV.usp_UpdateDepartments";
        //        command.CommandType = CommandType.StoredProcedure;


        //        command.Parameters.Clear();

        //        command.Parameters.AddWithValue("@DeptID", department.DeptID);
        //        command.Parameters.AddWithValue("@DeptName", department.DeptName);

        //        command.Connection = connection;
        //        connection.Open();
        //        int NoOfRowsAffected = command.ExecuteNonQuery();


        //        isUpdate = NoOfRowsAffected == 1;

        //    }
        //    catch (SqlException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (Exception Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return isUpdate;
        //}

        //public bool DeleteDepartments(int departmentid)
        //{
        //    bool isDelete = false;
        //    try
        //    {
        //        command.CommandText = "FIS_14_NOV.usp_DeleteDepartments";
        //        command.CommandType = CommandType.StoredProcedure;


        //        command.Parameters.Clear();

        //        command.Parameters.AddWithValue("@DeptID", departmentid);



        //        command.Connection = connection;
        //        connection.Open();
        //        int NoOfRowsAffected = command.ExecuteNonQuery();


        //        isDelete = NoOfRowsAffected == 1;

        //    }
        //    catch (SqlException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (Exception Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return isDelete;
        //}

        //public bool AddCourses(CoursesEntity course)
        //{
        //    bool isAdded = false;
        //    try
        //    {
        //        command.CommandText = "FIS_14_NOV.usp_AddCourse";
        //        command.CommandType = CommandType.StoredProcedure;


        //        command.Parameters.Clear();

        //        command.Parameters.AddWithValue("@CourseName", course.CourseName);
        //        command.Parameters.AddWithValue("@CourseCredits", course.CourseCredits);
        //        command.Parameters.AddWithValue("@DeptID", course.DeptID);


        //        command.Connection = connection;
        //        connection.Open();
        //        int NoOfRowsAffected = command.ExecuteNonQuery();


        //        isAdded = NoOfRowsAffected == 1;

        //    }
        //    catch (SqlException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (Exception Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return isAdded;
        //}
        //public bool UpdateCourses(CoursesEntity course)
        //{
        //    bool isUpdate = false;
        //    try
        //    {
        //        command.CommandText = "FIS_14_NOV.usp_UpdateCourses";
        //        command.CommandType = CommandType.StoredProcedure;


        //        command.Parameters.Clear();
        //        command.Parameters.AddWithValue("@CourseID", course.CourseID);
        //        command.Parameters.AddWithValue("@CourseName", course.CourseName);
        //        command.Parameters.AddWithValue("@CourseCredits", course.CourseCredits);
        //        command.Parameters.AddWithValue("@DeptID", course.DeptID);



        //        command.Connection = connection;
        //        connection.Open();
        //        int NoOfRowsAffected = command.ExecuteNonQuery();


        //        isUpdate = NoOfRowsAffected == 1;

        //    }
        //    catch (SqlException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (Exception Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return isUpdate;
        //}
        //public bool DeleteCourses(int CourseId)
        //{
        //    bool isDelete = false;
        //    try
        //    {
        //        command.CommandText = "FIS_14_NOV.usp_DeleteCourses";
        //        command.CommandType = CommandType.StoredProcedure;

        //        command.Parameters.Clear();
        //        command.Parameters.AddWithValue("@CourseID", CourseId);
        //        command.Connection = connection;
        //        connection.Open();
        //        int NoOfRowsAffected = command.ExecuteNonQuery();

        //        isDelete = NoOfRowsAffected == 1;

        //    }
        //    catch (SqlException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    catch (Exception Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //    return isDelete;
        //}
        public bool AddDesignation(DesignationEntity designation)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_AddDesignation";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@DesignationID", designation.DesignationID);
                command.Parameters.AddWithValue("@DesignationName", designation.DesignationName);


                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }
        public bool UpdateDesignation(DesignationEntity designation)
        {
            bool isUpdate = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_UpdateDesignation";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                command.Parameters.AddWithValue("@DesignationID", designation.DesignationID);
                command.Parameters.AddWithValue("@DesignationName", designation.DesignationName);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeleteDesignation(int DesignationId)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_DeleteDepartment";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@DesignationId", DesignationId);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }

        public bool AddSubjects(SubjectEntity subject)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_AddSubject]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@SubjectName", subject.SubjectName);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public SubjectEntity SearchSubjectDAL(int searchSubjectID)
        {
            SubjectEntity searchSubject = null;
            try
            {
                command.CommandText = "[FIS_14_NOV].usp_SearchSubject";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@SubjectId", searchSubjectID);

                SqlDataReader reader;
                command.Connection = connection;
                connection.Open();

                reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        searchSubject = new SubjectEntity();
                        searchSubject.SubjectID = reader.GetInt32(0);
                        searchSubject.SubjectName = reader.GetString(1);


                    }
                }
                reader.Close();
                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchSubject;
        }

        public bool UpdateSubjects(SubjectEntity subject)
        {
            bool isUpdate = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_UpdateSubject";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                command.Parameters.AddWithValue("@SubjectID", subject.SubjectID);
                command.Parameters.AddWithValue("@SubjectName", subject.SubjectName);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeleteSubjects(int SubjectID)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_DeleteSubject";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@SubjectID", SubjectID);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }

        public DataTable GetAllSubjectsDAL()
        {
            DataTable table = new DataTable();
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_ViewSubjects]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);

               //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

        public List<PublicationsEntity> ViewPublications()
        {
            List<PublicationsEntity> lstPublications = new List<PublicationsEntity>();

            try
            {
                SqlDataReader ObjSqlDataReader;
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_GetPublications";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    PublicationsEntity publications;

                    while (ObjSqlDataReader.Read())
                    {
                        publications = new PublicationsEntity();

                        publications.PublicationID = ObjSqlDataReader.GetInt32(0);
                        publications.FacultyID = ObjSqlDataReader.GetInt32(1);
                        publications.PublicationTitle = ObjSqlDataReader.GetString(2);
                        publications.ArticleName = ObjSqlDataReader.GetString(3);
                        publications.PublisherName = ObjSqlDataReader.GetString(4);
                        publications.PublicationLocation = ObjSqlDataReader.GetString(5);
                        publications.CitationDate = ObjSqlDataReader.GetDateTime(6);

                        lstPublications.Add(publications);
                    }
                }
                ObjSqlDataReader.Close();

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }



            return lstPublications;
        }

        public List<PublicationsEntity> ViewPublicationsByYearDAL(string year)
        {
            List<PublicationsEntity> lstPublications = new List<PublicationsEntity>();

            try
            {
                SqlDataReader ObjSqlDataReader;
                command = new SqlCommand();
                command.CommandText = "[FIS_14_NOV].[usp_GetPublicationsByYear]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@year", year);
                command.Connection = connection;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    PublicationsEntity publications;

                    while (ObjSqlDataReader.Read())
                    {
                        publications = new PublicationsEntity();

                        publications.PublicationID = ObjSqlDataReader.GetInt32(0);
                        publications.FacultyID = ObjSqlDataReader.GetInt32(1);
                        publications.PublicationTitle = ObjSqlDataReader.GetString(2);
                        publications.ArticleName = ObjSqlDataReader.GetString(3);
                        publications.PublisherName = ObjSqlDataReader.GetString(4);
                        publications.PublicationLocation = ObjSqlDataReader.GetString(5);
                        publications.CitationDate = ObjSqlDataReader.GetDateTime(6);

                        lstPublications.Add(publications);
                    }
                }
                ObjSqlDataReader.Close();

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }



            return lstPublications;
        }

        public WorkHistory SearchWorkHistoryDAL(int searchWorkID)
        {
            WorkHistory workHistory = new WorkHistory();
            try
            {
                command = new SqlCommand();
                command.CommandText = "[FIS_14_NOV].[usp_SearchWorkInformation]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@WorkId", searchWorkID);
                command.Connection = connection;
                SqlDataReader reader;
                connection.Open();

                reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        workHistory = new WorkHistory();
                        workHistory.WorkHistoryID = reader.GetInt32(0);
                        workHistory.FacultyID = reader.GetInt32(1);
                        workHistory.Organization = reader.GetString(2);
                        workHistory.JobTitle = reader.GetString(3);
                        workHistory.JobBeginDate = reader.GetDateTime(4);
                        workHistory.JobEndDate = reader.GetDateTime(5);
                        workHistory.JobResponsibilities = reader.GetString(6);
                        workHistory.JobType = reader.GetString(7);
                    }
                }
                reader.Close();
                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return workHistory;
        }

        public bool UpdateWorkInformation(WorkHistory workHistory)
        {
            bool isUpdate = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_UpdateWorkHistory";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@WorkHistoryID", workHistory.WorkHistoryID);
                command.Parameters.AddWithValue("@FacultyID", workHistory.FacultyID);
                command.Parameters.AddWithValue("@Organization", workHistory.Organization);
                command.Parameters.AddWithValue("@JobTitle", workHistory.JobTitle);
                command.Parameters.AddWithValue("@JobBeginDate", workHistory.JobBeginDate);
                command.Parameters.AddWithValue("@JobEndDate", workHistory.JobEndDate);
                command.Parameters.AddWithValue("@JobResponsibilities", workHistory.JobResponsibilities);
                command.Parameters.AddWithValue("@JobType", workHistory.JobType);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public DataTable GetAllWorkDAL()
        {
            DataTable table = new DataTable();
            try
            {
                command = new SqlCommand();
                command.CommandText = "[FIS_14_NOV].[usp_ViewWorkInformation]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);


                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

        public bool AddCourses(CoursesEntity course)
        {
            bool isAdded = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_AddCourse";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@CourseName", course.CourseName);
                command.Parameters.AddWithValue("@CourseCredits", course.CourseCredits);
                command.Parameters.AddWithValue("@DeptID", course.DeptID);
                command.Connection = connection;


                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public CoursesEntity SearchCoursesDAL(int searchCourseID)
        {
            CoursesEntity searchCourse = new CoursesEntity();
            try
            {
                command = new SqlCommand();
                command.CommandText = "[FIS_14_NOV].[usp_SearchCourses]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@CourseId", searchCourseID);
                command.Connection = connection;
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        searchCourse.CourseID = int.Parse(reader[0].ToString());
                        searchCourse.CourseName = reader[1].ToString();
                        searchCourse.CourseCredits = int.Parse(reader[2].ToString());
                        searchCourse.DeptID = int.Parse(reader[3].ToString());

                    }
                }
                reader.Close();
                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchCourse;
        }

        public bool UpdateCourses(CoursesEntity course)
        {
            bool isUpdate = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_UpdateCourses";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                command.Parameters.AddWithValue("@CourseID", course.CourseID);
                command.Parameters.AddWithValue("@CourseName", course.CourseName);
                command.Parameters.AddWithValue("@CourseCredits", course.CourseCredits);
                command.Parameters.AddWithValue("@DeptID", course.DeptID);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();
                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeleteCourses(int CourseId)
        {
            bool isDelete = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_DeleteCourses";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@CourseID", CourseId);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }
        public DataTable GetAllCoursesDAL()
        {
            DataTable table = new DataTable();
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_SelectCourses";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);

                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }
    }
}
