﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EMSException;
using EMSEntity;
using EMSBLL;

namespace EMSPL
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserEntity newUser = new UserEntity();
                newUser.UserName = txtUsername.Text;
                newUser.Password = txtPassword.Password.ToString();

                newUser.UserType = ((ComboBoxItem)CbUserType.SelectedItem).Content.ToString();


                UserBLL userBLL = new UserBLL();
                if (userBLL.GetPassword(newUser))
                {
                    Application.Current.Resources["username"] = txtUsername.Text;
                    if (newUser.UserType == "Student")
                    {
                        NavigationService nav = NavigationService.GetNavigationService(this);
                        nav.Navigate(new Uri("SearchPublication.xaml", UriKind.RelativeOrAbsolute));

                    }
                    else if (newUser.UserType == "Admin")
                    {
                        NavigationService nav = NavigationService.GetNavigationService(this);
                        nav.Navigate(new Uri("HomeAdmin.xaml", UriKind.RelativeOrAbsolute));
                    }
                    else if (newUser.UserType == "Faculty")
                    {
                        NavigationService nav = NavigationService.GetNavigationService(this);
                        nav.Navigate(new Uri("HomeFaculty.xaml", UriKind.RelativeOrAbsolute));
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");

                }
            }
            catch (EMSException.EMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("All Fields are Required");
            }
        }
    
    }
}
