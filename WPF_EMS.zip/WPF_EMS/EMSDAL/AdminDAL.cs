﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEntity;
using EMSException;
using System.Configuration;

namespace EMSDAL
{
    public class AdminDAL
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        SqlCommand command = new SqlCommand();

        public bool AddUserDAL(UserEntity user)
        {
            bool isAdded = false;
            try
            {

                command.CommandText = "FIS_14_NOV.usp_InsertUsers";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@UserName", user.UserName);
                command.Parameters.AddWithValue("@Password", user.Password);
                command.Parameters.AddWithValue("@UserType", user.UserType);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public bool AddDesignation(DesignationEntity designation)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "usp_AddDesignation";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@DesignationID", designation.DesignationID);
                command.Parameters.AddWithValue("@DesignationName", designation.DesignationName);


                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public bool DeleteDesignationDAL(int DesignationId)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "usp_DeleteDepartment";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@DesignationId", DesignationId);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }

        public List<DesignationEntity> ViewDesignations()
        {
            List<DesignationEntity> lstDesignations = new List<DesignationEntity>();

            try
            {
                SqlDataReader ObjSqlDataReader;
                command = new SqlCommand();
                command.CommandText = "usp_GetDesignations";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    DesignationEntity designation;

                    while (ObjSqlDataReader.Read())
                    {
                        designation = new DesignationEntity();

                        designation.DesignationID = ObjSqlDataReader.GetInt32(0);                       
                        designation.DesignationName = ObjSqlDataReader.GetString(1);

                        lstDesignations.Add(designation);
                    }
                }
                ObjSqlDataReader.Close();

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return lstDesignations;
        }

        public bool AddBusinessUnitDAL(BU_Entity businessUnit)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "usp_AddBusinessUnit";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@BU_ID", businessUnit.BU_ID);
                command.Parameters.AddWithValue("@BU_Name", businessUnit.BU_Name);


                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public List<BU_Entity> ViewBusinessUnitDAL()
        {
            List<BU_Entity> lstBusinessUnit = new List<BU_Entity>();

            try
            {
                SqlDataReader ObjSqlDataReader;
                command = new SqlCommand();
                command.CommandText = "usp_GetBusinessUnit";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Connection = connection;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    BU_Entity businessUnit;

                    while (ObjSqlDataReader.Read())
                    {
                        businessUnit = new BU_Entity();

                        businessUnit.BU_ID = ObjSqlDataReader.GetInt32(0);
                        businessUnit.BU_Name = ObjSqlDataReader.GetString(1);

                        lstBusinessUnit.Add(businessUnit);
                    }
                }
                ObjSqlDataReader.Close();

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return lstBusinessUnit;
        }

        public bool DeleteBusinessUnitDAL(int businessUnitId)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "usp_DeleteBusinessUnit";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@BU_Id", businessUnitId);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }
    }
}
