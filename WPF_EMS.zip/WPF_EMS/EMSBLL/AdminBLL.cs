﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSDAL;
using EMSEntity;
using EMSException;

namespace EMSBLL
{
    public class AdminBLL
    {
        AdminDAL adminDAL = new AdminDAL();
        //User Validation
        private bool ValidateUser(EMSEntity.UserEntity User)
        {
            StringBuilder sb = new StringBuilder();
            bool validateUser = true;
            if (User.UserName == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "User Name Required");
            }
            if (User.Password.Length < 8)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password should not be less than 8 characters");
            }
            if (User.UserType == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "UserType is Required");
            }
            if (validateUser == false)
                throw new EMSException.EMSException(sb.ToString());
            return validateUser;

        }
        public bool AddUser(EMSEntity.UserEntity User)
        {
            bool isAdded = false;
            try
            {
                if (ValidateUser(User))
                {
                    isAdded = adminDAL.AddUserDAL(User);
                }
            }

            catch (EMSException.EMSException ex)
            {
                throw new EMSException.EMSException(ex.Message);
            }
            return isAdded;

        }

        public bool AddDesignationBLL(DesignationEntity designation)
        {
            bool isAdded = false;
            try
            {
                isAdded = adminDAL.AddDesignation(designation);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            return isAdded;

        }

        public bool DeleteDesignationBLL(int designationId)
        {
            bool isDeleted = false;
            try
            {
                isDeleted = adminDAL.DeleteDesignationDAL(designationId);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            return isDeleted;

        }

        public List<DesignationEntity> ViewAllDesignationBLL()
        {
            List<DesignationEntity> lstDesignations = new List<DesignationEntity>();

            try
            {
                lstDesignations = adminDAL.ViewDesignations();

            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }

            return lstDesignations;
        }

        public bool AddBusinessUnitBLL(BU_Entity businessUnit)
        {
            bool isAdded = false;
            try
            {
                isAdded = adminDAL.AddBusinessUnitDAL(businessUnit);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            return isAdded;

        }

        public bool DeleteBusinessUnitBLL(int businessUnitId)
        {
            bool isDeleted = false;
            try
            {
                isDeleted = adminDAL.DeleteBusinessUnitDAL(businessUnitId);
            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }
            return isDeleted;

        }

        public List<BU_Entity> ViewAllBusinessUnitBLL()
        {
            List<BU_Entity> lstBusinessUnits = new List<BU_Entity>();

            try
            {
                lstBusinessUnits = adminDAL.ViewBusinessUnitDAL();

            }
            catch (EMSException.EMSException Exception)
            {
                throw new EMSException.EMSException(Exception.Message);
            }

            return lstBusinessUnits;
        }
    }
}
