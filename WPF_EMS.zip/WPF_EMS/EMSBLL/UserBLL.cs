﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSDAL;
using EMSEntity;
using EMSException;

namespace EMSBLL
{
    public class UserBLL
    {
        static EMSDAL.UserDAL userDAL = new EMSDAL.UserDAL();

        private bool ValidateUser(EMSEntity.UserEntity User)
        {
            StringBuilder sb = new StringBuilder();
            bool validateUser = true;
            if (User.UserName == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "User Name Required");
            }
            if (User.Password.Length < 8)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password should not be less than 8 characters");
            }
            if (User.Password == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password Required");
            }
            if (User.UserType == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "UserType is Required");
            }
            if (validateUser == false)
                throw new EMSException.EMSException(sb.ToString());
            return validateUser;

        }


        public bool GetPassword(UserEntity user)
        {
            bool isuserValid = false;
            try
            {
                if (ValidateUser(user))
                {
                    isuserValid = userDAL.GetUserPassword(user);
                }
                else
                {
                    throw new EMSException.EMSException();
                }

            }
            catch (EMSException.EMSException exception)
            {
                throw exception;

            }
            return isuserValid;
        }
    }
}
